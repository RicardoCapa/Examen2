from django.contrib import admin
from .models import Producto

class AdminProducto(admin.ModelAdmin):
	list_display = ["identificador","nombre","precio","descripcion","fecha_vencimiento",
		"cantidad_productos"]
	list_editable = ["nombre","precio","descripcion","fecha_vencimiento",
		"cantidad_productos"]
	list_filter= ["fecha_vencimiento"]

	class Meta:
		model = Producto
admin.site.register(Producto,AdminProducto)