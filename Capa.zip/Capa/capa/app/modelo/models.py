from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import MaxValueValidator

class Producto(models.Model):

	identificador = models.CharField('Identificador',max_length=10, null=False)
	nombre = models.CharField('Nombre',max_length=25,blank=False, null=False)
	precio = models.CharField('Precio',max_length=25,blank=False, null=False)
	descripcion = models.CharField('Descripcion',max_length=25, blank=False, null=False)
	fecha_vencimiento = models.DateField()
	cantidad_productos = models.CharField(max_length=10, null=False)

